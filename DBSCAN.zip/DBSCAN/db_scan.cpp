#include<stdio.h>
#include <cstdlib>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n, l;
	cout<<" Density based clusters "<<endl;
	cin>>n>>l;
	int len_data = n;
	float a[n][2], d;
	int i, j, k, m, p;
	float eps ;
	int min_p ;
	cin>>min_p>>eps;
	for(i=0; i<n; i++)
	{
		cin>>a[i][0]>>a[i][1];
	}
	//for(i=0; i<10; i++)
	//	cout<<a[i][0]<<"  "<<a[i][1]<<endl;
	//cout<<"chala"<<endl;
	int  x, y , z;
	int c[n]={0}, visit[n]={0};
	float dist[n] ={0};
	for(k=0; k<n; k++)
		c[k] = 0;
	for(k=0; k<n; k++)
		dist[k] = 0;
	for(k=0; k<n; k++)
		visit[k] = 0;
	int count=0, bre=0;
	int clus = len_data/min_p + 1;
	while(clus--)
	{
		for(i=0; i<n; i++)
		{
			if(visit[i] == 0)
			{
				visit[i] = clus;
				break;
			}
		}
		for(i=0; i<n; i++)
		{
			count=0;
			if(visit[i] == clus)
			{
				l=0;
				for(k=0; k<n; k++)
					c[k] = 0;
				for(k=0; k<n; k++)
					dist[k] = 0;
				for(j=0; j<n; j++)
				{
					d = (a[i][0] - a[j][0])*(a[i][0] - a[j][0]) + (a[i][1] - a[j][1])*(a[i][1] - a[j][1]);
					d = sqrt(d);
					dist[j] = d;
				//	cout<<"d = "<<d<<endl;
				}
				for(j=0; j<n; j++)
				{
					if(dist[j] <= eps)
					{
						c[l++] = j;
						count++;
					}
				}
				//cout<<"count = "<<count<<endl;
				if(count >= min_p)
				{
					for(k=0; k<l; k++)
					{
						visit[c[k]] = clus;
					//	cout<<"j = "<<c[k]<<"   "<<clus<<endl;
					}
				}
				
			}
		}
		bre=0;
		for(i=0; i<n; i++)
		{
			if(visit[i] == 0)
			{
				bre++;
			}
		}
		//cout<<"unvisited = "<<bre<<endl;
		if(bre == 0)
			break;
	}
	//cout<<"Bahar"<<endl;
	clus = len_data/min_p + 1;
	int total=0, vi=0;
	while(clus--)
	{
		total =1;
		for(i=0; i<n; i++)
		{
			if(visit[i] == clus)
			{
			//	cout<<total<<" = cluster_element = "<<clus<<" ------ "<<a[i][0]<<"     "<<a[i][1]<<endl;
				total++; 
			}
		}
		if(total >= min_p && clus > 0) 
			cout<<clus<<" = cluster_element ---- TOTAL SIZE = "<<total<<" ------ "<<endl;
		else
			vi = vi + total;	
	}
	cout<<" ---- UNVISITED OUTLIER ELEMENTS = "<<vi<<" ---------"<<endl; 
}
